from django.contrib import admin

# Register your models here.
from .models import Pet
class Petadmin(admin.ModelAdmin):
    list_display=['image','name','gender','age','description','breed','price']
    fields=['image','name','gender','age','description','breed','price']
    # list_editable=['image','name','gender','age','description','breed','price']
    # list_display_links=['id']
    # list_editable=['image','name','gender','age','description','breed','price']
admin.site.register(Pet,Petadmin)