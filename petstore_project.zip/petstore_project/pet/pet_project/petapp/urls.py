from django.urls import path
from . import views
urlpatterns=[
    path('list_all',views.list_all,name='list_pets'),
    path('<int:id>',views.list_detail,name='list_detail'),
    path('',views.signup),
    path('login_view',views.login_view),
    path('search_result',views.search_result,name='search_result'),
    path('add_to_cart/<int:pet_id>',views.add_to_cart,name='add_to_cart'),
    path('cart-items',views.cart_items,name='cart_items'),
    path('remove_from_cart/<int:pet_id>',views.remove_from_cart,name='remove_from_cart'),
    path('add_address',views.add_address,name='add_address'),
    path('set_delivery_address',views.set_delivery_address,name='set_delivery_address'),
    path('order_review/<int:sa_id>',views.order_review,name='order_review'),
    path('checkout_order/<int:sa_id>',views.checkout_order,name='checkout_order'),
    path('payment_order/',views.payment_order,name='payment_order'),
    path('payment-process/<int:order_id>/<int:amount>', views.payment_process, name="payment_process")
   
   
]