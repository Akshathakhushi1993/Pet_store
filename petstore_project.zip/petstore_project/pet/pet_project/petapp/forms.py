from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import ShippingAddress

PRODUCT_QUANTITY_CHOICES=[(i,str(i)) for i in range(1,21)]
class CartAddprodcutform(forms.Form):
    quanity=forms.TypedChoiceField(choices=PRODUCT_QUANTITY_CHOICES,coerce=int)
    update=forms.BooleanField(required=False,initial=False,widget=forms.HiddenInput)
class ShippingAddressForm(forms.ModelForm):
    class Meta:
        model = ShippingAddress
        fields = ['building_name', 'street', 'landmark', 'city', 'state', 'zipcode']
class SetDeliveryAddressForm(forms.Form):
    delivery_address = forms.CharField()