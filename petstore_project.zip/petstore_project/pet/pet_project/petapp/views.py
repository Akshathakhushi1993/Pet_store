from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
from django.contrib.auth import authenticate,login,logout
from django.db.models import Q
from .models import Cartitem,Customer,ShippingAddress,Order,OrderItem
from .forms import ShippingAddressForm,SetDeliveryAddressForm
# Create your views here.
from .models import Pet
from django.conf import settings
from django.urls import reverse
from django.shortcuts import get_object_or_404
import razorpay
def list_all(request):
    s=Pet.objects.all()
    return render(request,'list.html',{'s':s})
def list_detail(request,id):
    data=Pet.objects.get(id=id)
    return render(request,'list_detail.html',{'data':data})
def signup(request):
    if request.method=='POST':
        fn=UserCreationForm(request.POST)
        if fn.is_valid():
            u = fn.save()
            cus = Customer.objects.create(user=u)
            print(cus)
            return redirect('/login_view')
    else:
        fn=UserCreationForm()
    return render(request,'signup.html',{'form':fn})
def login_view(request):
    if request.method=='POST':
        fn=AuthenticationForm(request,data=request.POST)
        if fn.is_valid():
            uname=fn.cleaned_data['username']
            upass=fn.cleaned_data['password']
            u1=authenticate(username=uname,password=upass)
            if u1 is not None:
                login(request,u1)
                return redirect('/list_all')
    else:
        fn=AuthenticationForm()
    return render(request,'login_view.html',{'form':fn})

def search_result(request):
    query=request.GET.get("q")
    print(query)
    data = Pet.objects.filter(Q(name__icontains=query)|Q(description__icontains=query))
    # data = Pet.objects.filter(Q(name__icontains=query)| Q(breed__icontains=query))
    context={'data':data,'query':query}
    return render(request,'search.html',context)
# from django.db.models import Q
# from .models import Pet  # Import your Pet model

# def search_result(request):
#     query = request.GET.get("q")

#     if query is not None and query.strip():  # Check if 'query' is not None and not empty
#         data = Pet.objects.filter(Q(name__icontains=query) | Q(price__icontains=query))
#     else:
#         data = []  # If 'query' is None or empty, set 'data' to an empty list

#     context = {'data': data, 'query': query}
#     return render(request, 'search.html', context)
def add_to_cart(request,pet_id):
    pet=Pet.objects.get(id=pet_id)
    customer=Customer.objects.get(user=request.user)
    existing_cart_items=Cartitem.objects.filter(customer=customer,pet=pet)
    if len(existing_cart_items)==0:
        cart_item=Cartitem.objects.create(customer=customer,pet=pet)
    else:
        cart_item=existing_cart_items[0]
    cart_item.quanity=request.POST['quanity']
    cart_item.save()
    return redirect('cart_items')


def collect_cart_details(request):
    cart_items_list=Cartitem.objects.filter(customer__user=request.user)
    qty_list=[n for n in range(1, 6)]
    all_items_price=0
    for item in cart_items_list:
        item.item_price=item.quanity*item.pet.price
        all_items_price=all_items_price + item.item_price
    context={
        'cart':cart_items_list,
        'total_price':all_items_price,
        'qty_list':qty_list
    }
    return context


def cart_items(request):
    context=collect_cart_details(request)
    return render(request,'cart_items.html', context=context)

def remove_from_cart(request,pet_id):
    pet=Pet.objects.get(id=pet_id)
    cart_item=Cartitem.objects.get(customer__user=request.user.id,pet=pet)
    cart_item.delete()
    return redirect('cart_items')
def add_address(request):
    if request.method == 'POST':
        form = ShippingAddressForm(request.POST)
        if form.is_valid():
            sd = form.save(commit=False)
            sd.customer = Customer.objects.get(user__id=request.POST['customer'])
            sd.save()
            return redirect('order_review',sa_id=sd.id)
    else:
        form = ShippingAddressForm()
    return render(request, 'add_address.html', {'form': form})
def set_delivery_address(request):
    
    addr_list = ShippingAddress.objects.filter(customer__user__id=request.user.id)
    if request.method == "POST":
        form = SetDeliveryAddressForm(request.POST)
        if form.is_valid():
            return redirect('order_review', sa_id=form.cleaned_data['delivery_address'])
    else:
        form = SetDeliveryAddressForm()
    context = {
        'address_list': addr_list,
        'form': form
    }
    return render(request, "delivery_address.html", context=context)
def order_review(request,sa_id):
    context=collect_cart_details(request)
    context['sa_id']=ShippingAddress.objects.get(id=sa_id)
    return render(request,'order_review.html',context=context)
def clear_cart_details(request):
    cart_items_list=Cartitem.objects.filter(customer__user=request.user)
    for item in cart_items_list:
        item.delete()

def checkout_order(request,sa_id):
    cart_items_list=collect_cart_details(request)['cart']
    customer=Customer.objects.filter(user=request.user)
    delivery_addr=ShippingAddress.objects.filter(id=sa_id)
    if customer:
        order=Order(customer=customer[0],shipping_address=delivery_addr[0])
        order.save()
        for item in cart_items_list:
            OrderItem.objects.create(
                order=order,
                product=item.pet,
                price=item.pet.price,
                quanity=item.quanity
            )
            clear_cart_details(request)
            request.session['order_id']=order.id
            return redirect(reverse('payment_order'))
        else:
            return redirect(reverse('list_pets'))
def payment_order(request):
    order_id=request.session.get('order_id')
    print("process_order order is -->",order_id)
    order=get_object_or_404(Order,id=order_id)
    amount=int(order.get_total_cost()*100)
    amount_inr=amount
    context={
        'order_id':order_id,
        'public_key':settings.RAZOR_KEY_ID,
        'amount':amount_inr,
        'amountring':amount
    }
    return render(request,'created.html',context=context)
client=razorpay.Client(auth=(settings.RAZOR_KEY_ID,settings.RAZOR_KEY_SECRET))
def payment_process(request, order_id, amount):
    order = get_object_or_404(Order, id=order_id)
    if request.method == "POST":
        order.complete = True
        order.save()
        print("Amount ", amount)
        print("Type amount str to int ", amount)
        payment_id = request.POST['razorpay_payment_id']
        print("Payment Id", payment_id)
        order.transaction_id = payment_id
        order.save()
        payment_client_capture = (client.payment.capture(payment_id, amount))
        print("Payment Client capture", payment_client_capture)
        payment_fetch = client.payment.fetch(payment_id)
        status = payment_fetch['status']
        amount_fetch = payment_fetch['amount']
        amount_fetch_inr = amount_fetch
        print("Payment Fetch", payment_fetch['status'])
        context = {
            'amount': amount_fetch_inr,
            'status': status,
            'transaction_id': payment_id
        }
        return render(request, 'done.html', context=context)