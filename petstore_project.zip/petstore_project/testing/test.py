def test_division():
    n=9
    d=2
    assert d!=0
    num=n/d
    print(num)
def greet():
    a=1
    assert a==a
    print(a)